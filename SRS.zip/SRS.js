document.getElementById("enquiryForm").addEventListener("submit" , function (e) {e.preventDefault();
    alert("Thank you for your enquiry! We'll get back to you soon.")
    this.reset();
});